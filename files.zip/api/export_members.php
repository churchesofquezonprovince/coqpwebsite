<?php
require_once '../config.php';

try {
    $format = isset($_GET['format']) ? sanitize_input($_GET['format']) : 'csv';
    
    $query = "SELECT 
                m.id, m.full_name, m.nickname, m.date_of_birth, m.age, m.locality, 
                m.permanent_address, m.home_address, m.category as member_category,
                cd.email, cd.contact_number,
                fi.parents_guardians_names, fi.emergency_contact, fi.emergency_contact_number, fi.shepherd as family_shepherd,
                ei.grade_level, ei.course_strand, ei.occupation_job, ei.school_workplace,
                ci.category as church_category, ci.date_of_baptism, ci.shepherd as church_shepherd, ci.introduced_by, ci.service, ci.status
              FROM members m
              LEFT JOIN contact_details cd ON m.id = cd.member_id
              LEFT JOIN family_information fi ON m.id = fi.member_id
              LEFT JOIN educational_information ei ON m.id = ei.member_id
              LEFT JOIN church_information ci ON m.id = ci.member_id
              ORDER BY m.created_at DESC";
    
    $result = $conn->query($query);
    
    if ($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="members_export_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        // Write headers
        $headers = [
            'ID', 'Full Name', 'Nickname', 'Date of Birth', 'Age', 'Locality',
            'Permanent Address', 'Home Address', 'Member Category', 'Email', 'Contact Number',
            'Parents/Guardians', 'Emergency Contact', 'Emergency Contact Number', 'Family Shepherd',
            'Grade Level', 'Course/Strand', 'Occupation/Job', 'School/Workplace',
            'Church Category', 'Date of Baptism', 'Church Shepherd', 'Introduced By', 'Service', 'Status'
        ];
        fputcsv($output, $headers);
        
        // Write data rows
        while ($row = $result->fetch_assoc()) {
            fputcsv($output, array_values($row));
        }
        
        fclose($output);
    } elseif ($format === 'json') {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="members_export_' . date('Y-m-d') . '.json"');
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>