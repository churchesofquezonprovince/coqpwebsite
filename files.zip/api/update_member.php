<?php
header('Content-Type: application/json');
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (empty($input['id'])) {
            respond(false, 'Member ID is required');
        }
        
        $member_id = (int)$input['id'];
        
        // Update members table
        if (isset($input['full_name']) || isset($input['date_of_birth']) || isset($input['category'])) {
            $full_name = isset($input['full_name']) ? sanitize_input($input['full_name']) : null;
            $nickname = isset($input['nickname']) ? sanitize_input($input['nickname']) : null;
            $date_of_birth = isset($input['date_of_birth']) ? sanitize_input($input['date_of_birth']) : null;
            $locality = isset($input['locality']) ? sanitize_input($input['locality']) : null;
            $permanent_address = isset($input['permanent_address']) ? sanitize_input($input['permanent_address']) : null;
            $home_address = isset($input['home_address']) ? sanitize_input($input['home_address']) : null;
            $category = isset($input['category']) ? sanitize_input($input['category']) : null;
            
            $updates = [];
            $params = [];
            $types = "";
            
            if ($full_name !== null) { $updates[] = "full_name = ?"; $params[] = $full_name; $types .= "s"; }
            if ($nickname !== null) { $updates[] = "nickname = ?"; $params[] = $nickname; $types .= "s"; }
            if ($date_of_birth !== null) { $updates[] = "date_of_birth = ?"; $params[] = $date_of_birth; $types .= "s"; }
            if ($locality !== null) { $updates[] = "locality = ?"; $params[] = $locality; $types .= "s"; }
            if ($permanent_address !== null) { $updates[] = "permanent_address = ?"; $params[] = $permanent_address; $types .= "s"; }
            if ($home_address !== null) { $updates[] = "home_address = ?"; $params[] = $home_address; $types .= "s"; }
            if ($category !== null) { $updates[] = "category = ?"; $params[] = $category; $types .= "s"; }
            
            if (!empty($updates)) {
                $params[] = $member_id;
                $types .= "i";
                $query = "UPDATE members SET " . implode(", ", $updates) . " WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param($types, ...$params);
                if (!$stmt->execute()) {
                    respond(false, 'Error updating member: ' . $stmt->error);
                }
            }
        }
        
        // Update contact details
        if (isset($input['email']) || isset($input['contact_number'])) {
            $email = isset($input['email']) ? sanitize_input($input['email']) : null;
            $contact_number = isset($input['contact_number']) ? sanitize_input($input['contact_number']) : null;
            
            // Check if record exists
            $check = "SELECT id FROM contact_details WHERE member_id = ?";
            $stmt = $conn->prepare($check);
            $stmt->bind_param("i", $member_id);
            $stmt->execute();
            $exists = $stmt->get_result()->num_rows > 0;
            
            if ($exists) {
                $updates = [];
                $params = [];
                $types = "";
                
                if ($email !== null) { $updates[] = "email = ?"; $params[] = $email; $types .= "s"; }
                if ($contact_number !== null) { $updates[] = "contact_number = ?"; $params[] = $contact_number; $types .= "s"; }
                
                if (!empty($updates)) {
                    $params[] = $member_id;
                    $types .= "i";
                    $query = "UPDATE contact_details SET " . implode(", ", $updates) . " WHERE member_id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param($types, ...$params);
                    $stmt->execute();
                }
            } else {
                $query = "INSERT INTO contact_details (member_id, email, contact_number) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("iss", $member_id, $email, $contact_number);
                $stmt->execute();
            }
        }
        
        // Update family information
        if (isset($input['parents_guardians_names']) || isset($input['emergency_contact'])) {
            $parents_guardians = isset($input['parents_guardians_names']) ? sanitize_input($input['parents_guardians_names']) : null;
            $siblings = isset($input['siblings_info']) ? json_encode($input['siblings_info']) : null;
            $emergency_contact = isset($input['emergency_contact']) ? sanitize_input($input['emergency_contact']) : null;
            $emergency_contact_number = isset($input['emergency_contact_number']) ? sanitize_input($input['emergency_contact_number']) : null;
            $shepherd = isset($input['shepherd']) ? sanitize_input($input['shepherd']) : null;
            
            $check = "SELECT id FROM family_information WHERE member_id = ?";
            $stmt = $conn->prepare($check);
            $stmt->bind_param("i", $member_id);
            $stmt->execute();
            $exists = $stmt->get_result()->num_rows > 0;
            
            if ($exists) {
                $updates = [];
                $params = [];
                $types = "";
                
                if ($parents_guardians !== null) { $updates[] = "parents_guardians_names = ?"; $params[] = $parents_guardians; $types .= "s"; }
                if ($siblings !== null) { $updates[] = "siblings_info = ?"; $params[] = $siblings; $types .= "s"; }
                if ($emergency_contact !== null) { $updates[] = "emergency_contact = ?"; $params[] = $emergency_contact; $types .= "s"; }
                if ($emergency_contact_number !== null) { $updates[] = "emergency_contact_number = ?"; $params[] = $emergency_contact_number; $types .= "s"; }
                if ($shepherd !== null) { $updates[] = "shepherd = ?"; $params[] = $shepherd; $types .= "s"; }
                
                if (!empty($updates)) {
                    $params[] = $member_id;
                    $types .= "i";
                    $query = "UPDATE family_information SET " . implode(", ", $updates) . " WHERE member_id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param($types, ...$params);
                    $stmt->execute();
                }
            } else {
                $query = "INSERT INTO family_information (member_id, parents_guardians_names, siblings_info, emergency_contact, emergency_contact_number, shepherd) 
                          VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("isssss", $member_id, $parents_guardians, $siblings, $emergency_contact, $emergency_contact_number, $shepherd);
                $stmt->execute();
            }
        }
        
        // Update educational information
        if (isset($input['grade_level']) || isset($input['school_workplace'])) {
            $grade_level = isset($input['grade_level']) ? sanitize_input($input['grade_level']) : null;
            $course_strand = isset($input['course_strand']) ? sanitize_input($input['course_strand']) : null;
            $occupation_job = isset($input['occupation_job']) ? sanitize_input($input['occupation_job']) : null;
            $school_workplace = isset($input['school_workplace']) ? sanitize_input($input['school_workplace']) : null;
            
            $check = "SELECT id FROM educational_information WHERE member_id = ?";
            $stmt = $conn->prepare($check);
            $stmt->bind_param("i", $member_id);
            $stmt->execute();
            $exists = $stmt->get_result()->num_rows > 0;
            
            if ($exists) {
                $updates = [];
                $params = [];
                $types = "";
                
                if ($grade_level !== null) { $updates[] = "grade_level = ?"; $params[] = $grade_level; $types .= "s"; }
                if ($course_strand !== null) { $updates[] = "course_strand = ?"; $params[] = $course_strand; $types .= "s"; }
                if ($occupation_job !== null) { $updates[] = "occupation_job = ?"; $params[] = $occupation_job; $types .= "s"; }
                if ($school_workplace !== null) { $updates[] = "school_workplace = ?"; $params[] = $school_workplace; $types .= "s"; }
                
                if (!empty($updates)) {
                    $params[] = $member_id;
                    $types .= "i";
                    $query = "UPDATE educational_information SET " . implode(", ", $updates) . " WHERE member_id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param($types, ...$params);
                    $stmt->execute();
                }
            } else {
                $query = "INSERT INTO educational_information (member_id, grade_level, course_strand, occupation_job, school_workplace) 
                          VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("issss", $member_id, $grade_level, $course_strand, $occupation_job, $school_workplace);
                $stmt->execute();
            }
        }
        
        // Update church information
        if (isset($input['date_of_baptism']) || isset($input['status'])) {
            $church_category = isset($input['church_category']) ? sanitize_input($input['church_category']) : null;
            $date_of_baptism = isset($input['date_of_baptism']) ? sanitize_input($input['date_of_baptism']) : null;
            $church_shepherd = isset($input['church_shepherd']) ? sanitize_input($input['church_shepherd']) : null;
            $introduced_by = isset($input['introduced_by']) ? sanitize_input($input['introduced_by']) : null;
            $service = isset($input['service']) ? sanitize_input($input['service']) : null;
            $status = isset($input['status']) ? sanitize_input($input['status']) : null;
            
            $check = "SELECT id FROM church_information WHERE member_id = ?";
            $stmt = $conn->prepare($check);
            $stmt->bind_param("i", $member_id);
            $stmt->execute();
            $exists = $stmt->get_result()->num_rows > 0;
            
            if ($exists) {
                $updates = [];
                $params = [];
                $types = "";
                
                if ($church_category !== null) { $updates[] = "category = ?"; $params[] = $church_category; $types .= "s"; }
                if ($date_of_baptism !== null) { $updates[] = "date_of_baptism = ?"; $params[] = $date_of_baptism; $types .= "s"; }
                if ($church_shepherd !== null) { $updates[] = "shepherd = ?"; $params[] = $church_shepherd; $types .= "s"; }
                if ($introduced_by !== null) { $updates[] = "introduced_by = ?"; $params[] = $introduced_by; $types .= "s"; }
                if ($service !== null) { $updates[] = "service = ?"; $params[] = $service; $types .= "s"; }
                if ($status !== null) { $updates[] = "status = ?"; $params[] = $status; $types .= "s"; }
                
                if (!empty($updates)) {
                    $params[] = $member_id;
                    $types .= "i";
                    $query = "UPDATE church_information SET " . implode(", ", $updates) . " WHERE member_id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param($types, ...$params);
                    $stmt->execute();
                }
            } else {
                $query = "INSERT INTO church_information (member_id, category, date_of_baptism, shepherd, introduced_by, service, status) 
                          VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("issssss", $member_id, $church_category, $date_of_baptism, $church_shepherd, $introduced_by, $service, $status);
                $stmt->execute();
            }
        }
        
        respond(true, 'Member updated successfully', ['member_id' => $member_id]);

    } catch (Exception $e) {
        respond(false, 'Error: ' . $e->getMessage());
    }
}
?>