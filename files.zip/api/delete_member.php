<?php
header('Content-Type: application/json');
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    try {
        $member_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        
        if ($member_id <= 0) {
            respond(false, 'Invalid member ID');
        }
        
        // Delete will cascade due to foreign keys
        $query = "DELETE FROM members WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $member_id);
        
        if ($stmt->execute()) {
            if ($stmt->affected_rows === 0) {
                respond(false, 'Member not found');
            }
            respond(true, 'Member deleted successfully');
        } else {
            respond(false, 'Error deleting member: ' . $stmt->error);
        }

    } catch (Exception $e) {
        respond(false, 'Error: ' . $e->getMessage());
    }
}
?>