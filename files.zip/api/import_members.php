<?php
header('Content-Type: application/json');
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    try {
        $file = $_FILES['file'];
        $file_type = pathinfo($file['name'], PATHINFO_EXTENSION);
        
        if ($file_type !== 'csv' && $file_type !== 'json') {
            respond(false, 'Invalid file format. Only CSV and JSON are supported');
        }
        
        $imported = 0;
        $errors = [];
        
        if ($file_type === 'csv') {
            $handle = fopen($file['tmp_name'], 'r');
            $headers = fgetcsv($handle); // Skip header row
            
            while (($row = fgetcsv($handle)) !== false) {
                try {
                    $data = array_combine($headers, $row);
                    
                    // Insert member
                    $query = "INSERT INTO members (full_name, nickname, date_of_birth, locality, permanent_address, home_address, category) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("sssssss", 
                        $data['Full Name'],
                        $data['Nickname'],
                        $data['Date of Birth'],
                        $data['Locality'],
                        $data['Permanent Address'],
                        $data['Home Address'],
                        $data['Member Category']
                    );
                    
                    if ($stmt->execute()) {
                        $member_id = $conn->insert_id;
                        $imported++;
                    }
                } catch (Exception $e) {
                    $errors[] = "Row " . ($imported + 1) . ": " . $e->getMessage();
                }
            }
            fclose($handle);
        } elseif ($file_type === 'json') {
            $json_data = json_decode(file_get_contents($file['tmp_name']), true);
            
            foreach ($json_data as $data) {
                try {
                    $query = "INSERT INTO members (full_name, nickname, date_of_birth, locality, permanent_address, home_address, category) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param("sssssss", 
                        $data['Full Name'],
                        $data['Nickname'],
                        $data['Date of Birth'],
                        $data['Locality'],
                        $data['Permanent Address'],
                        $data['Home Address'],
                        $data['Member Category']
                    );
                    
                    if ($stmt->execute()) {
                        $imported++;
                    }
                } catch (Exception $e) {
                    $errors[] = $e->getMessage();
                }
            }
        }
        
        respond(true, "Import completed. $imported records imported.", [
            'imported' => $imported,
            'errors' => $errors
        ]);

    } catch (Exception $e) {
        respond(false, 'Error: ' . $e->getMessage());
    }
}
?>