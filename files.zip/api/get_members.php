<?php
header('Content-Type: application/json');
require_once '../config.php';

try {
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    $search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
    $category = isset($_GET['category']) ? sanitize_input($_GET['category']) : '';
    $status = isset($_GET['status']) ? sanitize_input($_GET['status']) : '';
    
    // Build query
    $where = "1=1";
    $params = [];
    $types = "";
    
    if (!empty($search)) {
        $search_term = "%$search%";
        $where .= " AND (m.full_name LIKE ? OR m.nickname LIKE ? OR cd.email LIKE ? OR cd.contact_number LIKE ?)";
        $params = [$search_term, $search_term, $search_term, $search_term];
        $types = "ssss";
    }
    
    if (!empty($category)) {
        $where .= " AND m.category = ?";
        $params[] = $category;
        $types .= "s";
    }
    
    if (!empty($status)) {
        $where .= " AND ci.status = ?";
        $params[] = $status;
        $types .= "s";
    }
    
    // Get total count
    $count_query = "SELECT COUNT(*) as total FROM members m 
                    LEFT JOIN contact_details cd ON m.id = cd.member_id
                    LEFT JOIN church_information ci ON m.id = ci.member_id
                    WHERE $where";
    
    $count_stmt = $conn->prepare($count_query);
    if (!empty($params)) {
        $count_stmt->bind_param($types, ...$params);
    }
    $count_stmt->execute();
    $total = $count_stmt->get_result()->fetch_assoc()['total'];
    
    // Get members with all related data
    $query = "SELECT 
                m.id, m.full_name, m.nickname, m.date_of_birth, m.age, m.locality, 
                m.permanent_address, m.home_address, m.category as member_category, m.created_at,
                cd.email, cd.contact_number,
                fi.parents_guardians_names, fi.siblings_info, fi.emergency_contact, fi.emergency_contact_number, fi.shepherd as family_shepherd,
                ei.grade_level, ei.course_strand, ei.occupation_job, ei.school_workplace,
                ci.category as church_category, ci.date_of_baptism, ci.shepherd as church_shepherd, ci.introduced_by, ci.service, ci.status
              FROM members m
              LEFT JOIN contact_details cd ON m.id = cd.member_id
              LEFT JOIN family_information fi ON m.id = fi.member_id
              LEFT JOIN educational_information ei ON m.id = ei.member_id
              LEFT JOIN church_information ci ON m.id = ci.member_id
              WHERE $where
              ORDER BY m.created_at DESC
              LIMIT ? OFFSET ?";
    
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $params[] = $limit;
        $params[] = $offset;
        $types .= "ii";
        $stmt->bind_param($types, ...$params);
    } else {
        $stmt->bind_param("ii", $limit, $offset);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $members = [];
    
    while ($row = $result->fetch_assoc()) {
        $row['siblings_info'] = !empty($row['siblings_info']) ? json_decode($row['siblings_info'], true) : [];
        $members[] = $row;
    }
    
    respond(true, 'Members retrieved successfully', [
        'members' => $members,
        'pagination' => [
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'pages' => ceil($total / $limit)
        ]
    ]);

} catch (Exception $e) {
    respond(false, 'Error: ' . $e->getMessage());
}
?>