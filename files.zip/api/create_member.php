<?php
header('Content-Type: application/json');
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get JSON input
        $input = json_decode(file_get_contents('php://input'), true);

        // Validate required fields
        $errors = [];
        
        if (empty($input['full_name'])) $errors[] = 'Full name is required';
        if (empty($input['date_of_birth'])) $errors[] = 'Date of birth is required';
        if (empty($input['category'])) $errors[] = 'Category is required';
        if (!empty($input['email']) && !validate_email($input['email'])) $errors[] = 'Invalid email format';
        if (!empty($input['date_of_birth']) && !validate_date($input['date_of_birth'])) $errors[] = 'Invalid date format (YYYY-MM-DD)';

        if (!empty($errors)) {
            respond(false, 'Validation errors', $errors);
        }

        // Sanitize inputs
        $full_name = sanitize_input($input['full_name']);
        $nickname = sanitize_input($input['nickname'] ?? '');
        $date_of_birth = sanitize_input($input['date_of_birth']);
        $locality = sanitize_input($input['locality'] ?? '');
        $permanent_address = sanitize_input($input['permanent_address'] ?? '');
        $home_address = sanitize_input($input['home_address'] ?? '');
        $category = sanitize_input($input['category']);

        // Insert into members table
        $query = "INSERT INTO members (full_name, nickname, date_of_birth, locality, permanent_address, home_address, category) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssss", $full_name, $nickname, $date_of_birth, $locality, $permanent_address, $home_address, $category);
        
        if (!$stmt->execute()) {
            respond(false, 'Error creating member: ' . $stmt->error);
        }

        $member_id = $conn->insert_id;

        // Insert contact details
        if (!empty($input['email']) || !empty($input['contact_number'])) {
            $email = sanitize_input($input['email'] ?? '');
            $contact_number = sanitize_input($input['contact_number'] ?? '');
            
            $query = "INSERT INTO contact_details (member_id, email, contact_number) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iss", $member_id, $email, $contact_number);
            $stmt->execute();
        }

        // Insert family information
        if (!empty($input['parents_guardians_names']) || !empty($input['emergency_contact'])) {
            $parents_guardians = sanitize_input($input['parents_guardians_names'] ?? '');
            $siblings = !empty($input['siblings_info']) ? json_encode($input['siblings_info']) : null;
            $emergency_contact = sanitize_input($input['emergency_contact'] ?? '');
            $emergency_contact_number = sanitize_input($input['emergency_contact_number'] ?? '');
            $shepherd = sanitize_input($input['shepherd'] ?? '');
            
            $query = "INSERT INTO family_information (member_id, parents_guardians_names, siblings_info, emergency_contact, emergency_contact_number, shepherd) 
                      VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("isssss", $member_id, $parents_guardians, $siblings, $emergency_contact, $emergency_contact_number, $shepherd);
            $stmt->execute();
        }

        // Insert educational information
        if (!empty($input['grade_level']) || !empty($input['school_workplace'])) {
            $grade_level = sanitize_input($input['grade_level'] ?? '');
            $course_strand = sanitize_input($input['course_strand'] ?? '');
            $occupation_job = sanitize_input($input['occupation_job'] ?? '');
            $school_workplace = sanitize_input($input['school_workplace'] ?? '');
            
            $query = "INSERT INTO educational_information (member_id, grade_level, course_strand, occupation_job, school_workplace) 
                      VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("issss", $member_id, $grade_level, $course_strand, $occupation_job, $school_workplace);
            $stmt->execute();
        }

        // Insert church information
        if (!empty($input['date_of_baptism']) || !empty($input['status'])) {
            $church_category = sanitize_input($input['church_category'] ?? $category);
            $date_of_baptism = sanitize_input($input['date_of_baptism'] ?? '');
            $church_shepherd = sanitize_input($input['church_shepherd'] ?? '');
            $introduced_by = sanitize_input($input['introduced_by'] ?? '');
            $service = sanitize_input($input['service'] ?? '');
            $status = sanitize_input($input['status'] ?? 'Active');
            
            $query = "INSERT INTO church_information (member_id, category, date_of_baptism, shepherd, introduced_by, service, status) 
                      VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("issssss", $member_id, $church_category, $date_of_baptism, $church_shepherd, $introduced_by, $service, $status);
            $stmt->execute();
        }

        respond(true, 'Member created successfully', ['member_id' => $member_id]);

    } catch (Exception $e) {
        respond(false, 'Error: ' . $e->getMessage());
    }
}
?>