<?php
header('Content-Type: application/json');
require_once '../config.php';

try {
    $member_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($member_id <= 0) {
        respond(false, 'Invalid member ID');
    }
    
    $query = "SELECT 
                m.id, m.full_name, m.nickname, m.date_of_birth, m.age, m.locality, 
                m.permanent_address, m.home_address, m.category as member_category, m.created_at, m.updated_at,
                cd.email, cd.contact_number,
                fi.parents_guardians_names, fi.siblings_info, fi.emergency_contact, fi.emergency_contact_number, fi.shepherd as family_shepherd,
                ei.grade_level, ei.course_strand, ei.occupation_job, ei.school_workplace,
                ci.category as church_category, ci.date_of_baptism, ci.shepherd as church_shepherd, ci.introduced_by, ci.service, ci.status
              FROM members m
              LEFT JOIN contact_details cd ON m.id = cd.member_id
              LEFT JOIN family_information fi ON m.id = fi.member_id
              LEFT JOIN educational_information ei ON m.id = ei.member_id
              LEFT JOIN church_information ci ON m.id = ci.member_id
              WHERE m.id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $member_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        respond(false, 'Member not found');
    }
    
    $member = $result->fetch_assoc();
    $member['siblings_info'] = !empty($member['siblings_info']) ? json_decode($member['siblings_info'], true) : [];
    
    respond(true, 'Member retrieved successfully', $member);

} catch (Exception $e) {
    respond(false, 'Error: ' . $e->getMessage());
}
?>