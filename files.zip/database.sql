-- Create database
CREATE DATABASE IF NOT EXISTS member_management;
USE member_management;

-- Personal Information Table
CREATE TABLE IF NOT EXISTS members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(255) NOT NULL,
    nickname VARCHAR(100),
    date_of_birth DATE NOT NULL,
    age INT GENERATED ALWAYS AS (YEAR(CURDATE()) - YEAR(date_of_birth) - (DATE_FORMAT(CURDATE(), '%m%d') < DATE_FORMAT(date_of_birth, '%m%d'))) STORED,
    locality VARCHAR(255),
    permanent_address TEXT,
    home_address TEXT,
    category ENUM('Student', 'Working One', 'Serving One') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Contact Details Table
CREATE TABLE IF NOT EXISTS contact_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL UNIQUE,
    email VARCHAR(255),
    contact_number VARCHAR(20),
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Family Information Table
CREATE TABLE IF NOT EXISTS family_information (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL UNIQUE,
    parents_guardians_names TEXT,
    siblings_info JSON,
    emergency_contact VARCHAR(255),
    emergency_contact_number VARCHAR(20),
    shepherd VARCHAR(255),
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Educational Information Table
CREATE TABLE IF NOT EXISTS educational_information (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL UNIQUE,
    grade_level VARCHAR(50),
    course_strand VARCHAR(100),
    occupation_job VARCHAR(100),
    school_workplace VARCHAR(255),
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Church Information Table
CREATE TABLE IF NOT EXISTS church_information (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL UNIQUE,
    category ENUM('Student', 'Working One', 'Serving One') NOT NULL,
    date_of_baptism DATE,
    shepherd VARCHAR(255),
    introduced_by VARCHAR(255),
    service VARCHAR(100),
    status ENUM('Dormant', 'Active') DEFAULT 'Active',
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- Indexes for better query performance
CREATE INDEX idx_full_name ON members(full_name);
CREATE INDEX idx_category ON members(category);
CREATE INDEX idx_status ON church_information(status);
CREATE INDEX idx_email ON contact_details(email);