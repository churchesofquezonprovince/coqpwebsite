<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'member_management');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to validate email
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Function to validate date format
function validate_date($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

// Function to calculate age
function calculate_age($dob) {
    $now = new DateTime();
    $birthdate = new DateTime($dob);
    $age = $now->diff($birthdate)->y;
    return $age;
}

// Grade level auto-update based on age
function get_grade_level($age, $category) {
    if ($category === 'Student') {
        if ($age >= 4 && $age <= 5) return 'Preschool';
        if ($age >= 6 && $age <= 7) return 'Grade 1';
        if ($age >= 7 && $age <= 8) return 'Grade 2';
        if ($age >= 8 && $age <= 9) return 'Grade 3';
        if ($age >= 9 && $age <= 10) return 'Grade 4';
        if ($age >= 10 && $age <= 11) return 'Grade 5';
        if ($age >= 11 && $age <= 12) return 'Grade 6';
        if ($age >= 13 && $age <= 15) return 'Grade 7-9';
        if ($age >= 16 && $age <= 18) return 'Grade 10-12';
        if ($age >= 19) return 'College';
    }
    return '';
}

// Response function
function respond($success, $message, $data = null) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}
?>